
Note that by filing an issue, you agree that you have read and agreed to
our contribution guidelines.

## NNG & Platform details.

<include NNG version, and platform/operating system, and if you are using
another programming language what language> 

## Expected Behavior

## Actual Behavior

## Steps to Reproduce

<If possible, if include a copy of, or link to, a minimal test program
to demonstrate the behavior.  We prefer test cases written in C when
possible.>
