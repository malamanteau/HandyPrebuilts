This contains the nng documentation for API users.

The documentation is written in asciidoc in the form of man pages.  It is
automatically formatted for display on the website.

It is possible to emit TROFF sources for use by the UNIX man page, and HTML
for online viewing.  asciidoctor supports PDF and EPUB formats via plugins,
so there are still more options available.

The man pages are in the "man" directory.  The reason those are separate
is that they get special treatment.  Other documentation is located here.
